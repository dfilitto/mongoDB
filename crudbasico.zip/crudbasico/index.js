let readline = require("readline-sync"); 
let { MongoClient } = require('mongodb');

let username = 'usuario';
let password = '1234567890';
let cluster = 'cluster0'; 
let dbname = 'catalogosites';
let collectionName = 'sites';

const url = `mongodb+srv://${username}:${password}@${cluster}.uvhrwxz.mongodb.net/${dbname}?retryWrites=true&w=majority`;
const client = new MongoClient(url);

async function main() {
    try {
            console.log("Exemplo de CRUD basico");
            //username = readline.question("Nome do Usuario: ");
            //password = readline.question("Senha: ");
    } catch (err) {
            console.error(err);
    } finally {
            // Fechar a conexão com o MongoDB Atlas
            await client.close();
    }
}      
main().catch(console.error);