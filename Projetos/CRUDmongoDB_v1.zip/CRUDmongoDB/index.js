const mongoose = require('mongoose');
const readlineSync = require('readline-sync');

// Substitua <username>, <password> e <myFirstDatabase> com seus valores
const uri = 'mongodb+srv://usuario:1234567890@cluster0.uvhrwxz.mongodb.net/catalogosites?retryWrites=true&w=majority&appName=Cluster0';

// Conecta ao MongoDB Atlas
mongoose.connect(uri)
  .then(() => console.log('Conectado ao MongoDB Atlas!')) // Mensagem de sucesso
  .catch(err => {
    console.error('Erro de conexão:', err); // Exibe mensagem de erro
    process.exit(1);  // Para a execução do programa em caso de erro
  });

  // Define o esquema para a coleção de sites, sem o campo `id` adicional
const siteSchema = new mongoose.Schema({
    nome: String,
    endereco: String,
  });
  
  // Cria um modelo com base no esquema definido
  const Site = mongoose.model('Site', siteSchema,"sites");
  
  // Função para criar um novo site
  async function createSite() {
    // Solicita ao usuário as informações do novo site
    const nome = readlineSync.question('Digite o nome do site: ');
    const endereco = readlineSync.question('Digite o endereço do site: ');
  
    // Cria uma nova instância do modelo Site com os dados fornecidos
    const site = new Site({ nome, endereco });
    // Salva o novo site no banco de dados
    await site.save();
    console.log('Site criado com sucesso!');
  }
  
  // Função para listar todos os sites
  async function readSites() {
    // Busca todos os sites no banco de dados
    const sites = await Site.find({});
    console.log('Lista de Sites:');
    // Itera sobre os sites e imprime suas informações
    sites.forEach(site => {
      console.log(`ID: ${site._id}, Nome: ${site.nome}, Endereço: ${site.endereco}`);
    });
  }
  
  // Função para atualizar um site existente
  async function updateSite() {
    // Solicita o ID do site a ser atualizado
    const id = readlineSync.question('Digite o ID do site que deseja atualizar: ');
    // Busca o site pelo ID
    const site = await Site.findById(id);
  
    // Verifica se o site foi encontrado
    if (!site) {
      console.log('Site não encontrado!');
      return;
    }
  
    // Solicita os novos dados do site
    const nome = readlineSync.question('Digite o novo nome do site: ');
    const endereco = readlineSync.question('Digite o novo endereço do site: ');
  
    // Atualiza os campos do site
    site.nome = nome;
    site.endereco = endereco;
    // Salva as alterações no banco de dados
    await site.save();
    console.log('Site atualizado com sucesso!');
  }
  
  // Função para deletar um site
  async function deleteSite() {
    // Solicita o ID do site a ser deletado
    const id = readlineSync.question('Digite o ID do site que deseja deletar: ');
    // Deleta o site pelo ID
    const result = await Site.findByIdAndDelete(id);
  
    // Verifica se o site foi deletado
    if (result) {
      console.log('Site deletado com sucesso!');
    } else {
      console.log('Site não encontrado!');
    }
  }
  
  // Função principal que exibe o menu e executa as operações CRUD
  async function main() {
    while (true) {
      // Exibe o menu de opções
      console.log('\nMenu:');
      console.log('1. Criar site');
      console.log('2. Listar sites');
      console.log('3. Atualizar site');
      console.log('4. Deletar site');
      console.log('5. Sair');
      // Solicita a escolha do usuário
      const choice = readlineSync.questionInt('Escolha uma opção: ');
  
      // Executa a função correspondente à escolha do usuário
      switch (choice) {
        case 1:
          await createSite();
          break;
        case 2:
          await readSites();
          break;
        case 3:
          await updateSite();
          break;
        case 4:
          await deleteSite();
          break;
        case 5:
          console.log('Saindo...');
          process.exit(0); // Encerra o programa
        default:
          console.log('Opção inválida! Tente novamente.');
      }
    }
  }
  
  // Inicia a função principal e captura erros
  main().catch(err => console.error(err));