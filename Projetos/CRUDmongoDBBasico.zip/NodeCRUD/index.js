const { MongoClient } = require('mongodb');

// Substitua os valores abaixo pelos seus próprios detalhes
const username = 'usuario';
const password = '1234567890';
const cluster = 'cluster0'; // Substitua pelo nome do seu cluster
const dbname = 'catalogosites';
const collectionName = 'sites';

const url = `mongodb+srv://${username}:${password}@${cluster}.uvhrwxz.mongodb.net/${dbname}?retryWrites=true&w=majority`;
const client = new MongoClient(url);
  
async function main() {
  try {
    await client.connect();
    console.log('Conectado ao MongoDB Atlas');
    const db = client.db(dbname);
    const collection = db.collection(collectionName);
    
    // Inserir um novo filme
    const novoSite = { nome: 'Make Indie Games', endereco: 'https://www.makeindiegames.com.br' };
    const resultadoInsercao = await collection.insertOne(novoSite);
    console.log('Site inserido:', resultadoInsercao.insertedId);

    // Listar todos os filmes
    const sites = await collection.find({}).toArray();
    console.log('Lista de sites:', sites);

    // Atualizar um site
    const filtroAtualizacao = { _id: resultadoInsercao.insertedId };
    const atualizacao = { $set: { nome: 'Senac' } };
    await collection.updateOne(filtroAtualizacao, atualizacao);
    console.log('Site atualizado');

    // Listar todos os filmes após atualização
    const filmesAtualizados = await collection.find({}).toArray();
    console.log('Lista de filmes atualizada:', filmesAtualizados);

    // Remover um site
    const filtroRemocao = { _id: resultadoInsercao.insertedId };
    await collection.deleteOne(filtroRemocao);
    console.log('Site removido');

    // Listar todos os filmes após remoção
    const filmesRestantes = await collection.find({}).toArray();
    console.log('Lista de sites restantes:', filmesRestantes);
  } catch (err) {
    console.error(err);
  } finally {
    // Fechar a conexão com o MongoDB Atlas
    await client.close();
  }
}

main().catch(console.error);