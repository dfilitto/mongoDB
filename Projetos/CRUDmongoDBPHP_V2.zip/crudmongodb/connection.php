<?php
// connection.php
$manager = new MongoDB\Driver\Manager("mongodb://localhost:27017");
?>