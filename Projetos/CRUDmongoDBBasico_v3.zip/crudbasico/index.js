let readline = require("readline-sync"); 
let { MongoClient,  ObjectId } = require('mongodb');

let username = 'usuario';
let password = '1234567890';
let cluster = 'cluster0'; 
let dbname = 'catalogosites';
let collectionName = 'sites';

const url = `mongodb+srv://${username}:${password}@${cluster}.uvhrwxz.mongodb.net/${dbname}?retryWrites=true&w=majority`;
const client = new MongoClient(url);


function exibirMenu(){
  let op = 0;
  console.clear();
  console.log("CRUD MongoDB");
  console.log("1 - Inserir");  
  console.log("2 - Alterar");         
  console.log("3 - Listar"); 
  console.log("4 - Localizar");
  console.log("5 - Excluir");
  console.log("6 - Sair");
  op = parseInt(readline.question("Opcao: "));
  return op;
}

async function main() {
    try {

        //conectar ao banco de dados
        await client.connect(); 
        console.log('Conectado ao MongoDB Atlas');
        //defini o banco de trabalho 
        let db = client.db(dbname); 
        //defini a coleção de trabalho
        let collection = db.collection(collectionName);
        //array de sites da coleção
        let sites = "";
        let site = ""; 
        //propriedades de um site que será armazenado na coleção
        let idSite = ""; 
        let nomeSite = "";
        let enderecoSite = "";
        //escolha da operação do menu
        let op = 0;
        //resultado das operações realizadas no sistema
        let resultado = "";
        //filtro usado nas buscas outras operações no banco
        let filtro = "";
        

        while (op !=6){
            op = exibirMenu();
            //insert
            if(op==1) {
                nomeSite = readline.question("Nome:");
                enderecoSite = readline.question("Endereco:");
                site = { 'nome': nomeSite, 'endereco': enderecoSite };
                resultado = await collection.insertOne(site);
                console.log('Site inserido:', resultado.insertedId);
            }
            //update
            if(op==2) {
                idSite = readline.question("Id:");
                filtro = { '_id': new ObjectId(idSite) };
                sites = await collection.find(filtro).toArray();
                console.log('Site a ser alterado:', sites[0]);
                console.log('Informe novamente os dados do site:');
                nomeSite = readline.question("Nome:");
                enderecoSite = readline.question("Endereco:");
                site = { $set: { 'nome': nomeSite,'endereco':enderecoSite } };
                await collection.updateOne(filtro, site);
                readline.question("Pressione enter para voltar ao menu");
            }

            if(op==3) {
                    sites = await collection.find({}).toArray();
                    console.log('Lista de sites:', sites);
                    readline.question("Pressione enter para voltar ao menu");
            }
           
            if(op==4) {
                nomeSite = readline.question("Nome:");
                filtro = { 'nome': { '$regex':`${nomeSite}`, '$options': 'i' } }; // 'i' torna a busca case-insensitive
                sites = await collection.find(filtro).toArray();
                console.log('Lista de sites:', sites);
                readline.question("Pressione enter para voltar ao menu");
            }
           
            if(op==5) {
                idSite = readline.question("Id:");
                filtro = { '_id': new ObjectId(idSite) };
                retorno = await collection.deleteOne(filtro);
                if(retorno.deletedCount > 0){
                    console.log("Registro excluido com sucesso!!!!!");
                }else {
                    console.log("Registro não encontrado!!!!!");
                }
                readline.question("Pressione enter para voltar ao menu");
            }
        }
    } catch (err) {
            console.error(err);
    } finally {
            // Fechar a conexão com o MongoDB Atlas
            await client.close();
    }
}      
main().catch(console.error);