const { MongoClient } = require('mongodb');

// Substitua os valores abaixo pelos seus próprios detalhes
const username = 'usuario';
const password = '1234567890';
const cluster = 'cluster0'; // Substitua pelo nome do seu cluster
const dbname = 'catalogosites';
const collectionName = 'sites';

const url = `mongodb+srv://${username}:${password}@${cluster}.uvhrwxz.mongodb.net/${dbname}?retryWrites=true&w=majority`;
//mongodb+srv://<username>:<password>@cluster0.uvhrwxz.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0
const client = new MongoClient(url);

async function main() {
    try {
        //conectar no bacno de dados
        await client.connect();
        console.log('Conectado ao MongoDB Atlas');
        const db = client.db(dbname);
        const collection = db.collection(collectionName);
        
        // Inserir um novo sites
        //let novoSite = { nome: 'games', endereco: 'https://www.uol.com.br' };
        //let resultadoInsercao = await collection.insertOne(novoSite);
        //console.log('Site inserido:', resultadoInsercao.insertedId);

        // Listar todos os sites
        //const sites = await collection.find({}).toArray();
        //console.log('Lista de sites:', sites);

        // Atualizar um site
        //const filtroAtualizacao = { _id: resultadoInsercao.insertedId };
        //const atualizacao = { $set: { nome: 'UOL' } };
        //await collection.updateOne(filtroAtualizacao, atualizacao);
        //console.log('Site atualizado');

        // Remover um site
        //const filtroRemocao = { _id: resultadoInsercao.insertedId };
        //await collection.deleteOne(filtroRemocao);
        //console.log('Site removido');

        const filtroRemocao = { "nome": "games" };
        await collection.deleteMany(filtroRemocao);
        console.log('Site removido');

        // Listar todos os sites
        const sites = await collection.find({}).toArray();
        console.log('Lista de sites:', sites);

    } catch (err) {
        console.error(err);
      } finally {
        // Fechar a conexão com o MongoDB Atlas
        await client.close();
      }
}

main().catch(console.error);